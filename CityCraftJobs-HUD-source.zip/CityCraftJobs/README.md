# CityCraftJobs 0.2.0 (HUD prototype)

Target: Minecraft 1.20.1 / Java 17 / Arclight, with Good Ol' Currency Reforged installed in `mods`.

## Included
- `/jobs` opens the CityCraft job selection GUI (Constructor, Mecanic, Gunoier, Electrician, Miner).
- Selected job is saved by player UUID.
- `/jobs pay <player> <amount>` gives physical Good Ol' Currency Reforged banknotes.
- Sidebar HUD shows a unique player ID, rank label, selected job, playtime and the total value of supported banknotes in the player's storage inventory/offhand.
- `/jobs hud` refreshes the HUD; `/jobs reload` reloads config.

## HUD and rank notes
- The HUD is a server-side scoreboard sidebar, not a custom client overlay. A true on-screen overlay requires a client-side mod/resource implementation.
- Rank is read from Bukkit `Player#getPlayerListName()`. This may show the Simple Ranks prefix only if Simple Ranks writes it to the player-list name. If it does not, the HUD displays Admin/Jucator as a fallback. A Simple Ranks JAR or its config may be needed for exact integration.
- Playtime uses Minecraft's `PLAY_ONE_MINUTE` statistic. The value is shown as hours and minutes.
- Cash scanning uses Arclight's NMS/CraftItemStack bridge and the confirmed Good Ol' Currency Reforged registry IDs. This requires testing on the exact Arclight build.
- The sidebar scoreboard may conflict with another plugin that also owns the scoreboard sidebar.

## Build
Requires JDK 17 and Gradle 8+:
`gradle build`

Output: `build/libs/CityCraftJobs-0.2.0.jar`

Install the resulting JAR in `plugins`; keep Good Ol' Currency Reforged in `mods`. Restart the server. Back up the server first.
