package ro.citycraft.jobs;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Statistic;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.*;

public final class CityCraftJobs extends JavaPlugin implements Listener {
    private NamespacedKey jobKey;
    private static final String TITLE = ChatColor.DARK_GRAY + "CityCraft " + ChatColor.GOLD + "| Joburi";
    private final LinkedHashMap<String, Job> jobs = new LinkedHashMap<>();
    private final Map<UUID, Scoreboard> hudBoards = new HashMap<>();
    private final Map<UUID, Scoreboard> oldBoards = new HashMap<>();
    private final Map<String, Integer> noteValues = Map.of(
        "good_ol_currency_reforged:one_dollar", 1,
        "good_ol_currency_reforged:five_dollar", 5,
        "good_ol_currency_reforged:ten_dollar", 10,
        "good_ol_currency_reforged:twenty_dollar", 20,
        "good_ol_currency_reforged:fifty_dollar", 50,
        "good_ol_currency_reforged:onehundred_dollar", 100
    );

    private record Job(String name, Material icon, String description) {}

    @Override public void onEnable() {
        saveDefaultConfig();
        jobKey = new NamespacedKey(this, "selected_job");
        jobs.put("constructor", new Job("Constructor", Material.BRICKS, "Construieste si repara in oras"));
        jobs.put("mecanic", new Job("Mecanic", Material.ANVIL, "Repara vehicule si componente"));
        jobs.put("gunoier", new Job("Gunoier", Material.BARREL, "Colecteaza deseurile orasului"));
        jobs.put("electrician", new Job("Electrician", Material.REDSTONE, "Repara instalatiile electrice"));
        jobs.put("miner", new Job("Miner", Material.IRON_PICKAXE, "Extrage resurse din mine"));
        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) updateHud(player);
        }, 20L, 20L);
        for (Player player : Bukkit.getOnlinePlayers()) updateHud(player);
        getLogger().info("CityCraftJobs pornit: joburi, HUD si plata cash Good Ol' Currency.");
    }

    @Override public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) restoreBoard(player);
        hudBoards.clear(); oldBoards.clear();
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTaskLater(this, () -> updateHud(event.getPlayer()), 20L);
    }

    @EventHandler public void onQuit(PlayerQuitEvent event) {
        restoreBoard(event.getPlayer());
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player p)) { sender.sendMessage("Comanda poate fi folosita doar in joc."); return true; }
            openJobs(p); return true;
        }
        if (args[0].equalsIgnoreCase("hud")) {
            if (!(sender instanceof Player p)) { sender.sendMessage("Comanda poate fi folosita doar in joc."); return true; }
            updateHud(p); p.sendMessage(ChatColor.GREEN + "HUD-ul CITYCRAFT a fost actualizat."); return true;
        }
        if (args[0].equalsIgnoreCase("pay")) {
            if (!sender.hasPermission("citycraftjobs.admin")) { sender.sendMessage(ChatColor.RED + "Nu ai permisiune."); return true; }
            if (args.length != 3) { sender.sendMessage(ChatColor.YELLOW + "Folosire: /jobs pay <jucator> <suma>"); return true; }
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { sender.sendMessage(ChatColor.RED + "Jucatorul nu este online."); return true; }
            int amount;
            try { amount = Integer.parseInt(args[2]); } catch (NumberFormatException ex) { sender.sendMessage(ChatColor.RED + "Suma trebuie sa fie numar intreg."); return true; }
            if (amount < 1 || amount > 100000) { sender.sendMessage(ChatColor.RED + "Suma permisa: 1 - 100000."); return true; }
            if (!payCash(target, amount)) { sender.sendMessage(ChatColor.RED + "Nu am putut crea bancnotele. Verifica Good Ol' Currency Reforged si compatibilitatea Arclight."); return true; }
            sender.sendMessage(ChatColor.GREEN + "Ai platit $" + amount + " lui " + target.getName() + ".");
            target.sendMessage(ChatColor.GREEN + "Ai primit salariul: " + ChatColor.GOLD + "$" + amount + ChatColor.GREEN + " in bancnote!");
            updateHud(target);
            return true;
        }
        if (args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("citycraftjobs.admin")) return true;
            reloadConfig(); sender.sendMessage(ChatColor.GREEN + "CityCraftJobs: configuratia a fost reincarcata."); return true;
        }
        sender.sendMessage(ChatColor.YELLOW + "Folosire: /jobs | /jobs hud | /jobs pay <jucator> <suma> | /jobs reload");
        return true;
    }

    private void openJobs(Player p) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        int[] slots = {10, 12, 14, 16, 22};
        int i = 0;
        for (Map.Entry<String, Job> entry : jobs.entrySet()) {
            Job job = entry.getValue();
            ItemStack item = new ItemStack(job.icon());
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(ChatColor.GOLD + job.name());
            meta.setLore(List.of(ChatColor.GRAY + job.description(), ChatColor.YELLOW + "Apasa pentru a alege jobul"));
            meta.getPersistentDataContainer().set(jobKey, PersistentDataType.STRING, entry.getKey());
            item.setItemMeta(meta);
            inv.setItem(slots[i++], item);
        }
        ItemStack info = new ItemStack(Material.BOOK);
        ItemMeta im = info.getItemMeta();
        im.setDisplayName(ChatColor.AQUA + "CityCraft Jobs");
        im.setLore(List.of(ChatColor.GRAY + "Alege un job pentru a incepe.", ChatColor.GRAY + "HUD-ul arata jobul, ID-ul, orele si banii cash."));
        info.setItemMeta(im); inv.setItem(4, info);
        p.openInventory(inv);
    }

    @EventHandler public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player p) || !TITLE.equals(event.getView().getTitle())) return;
        event.setCancelled(true);
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || !clicked.hasItemMeta()) return;
        String id = clicked.getItemMeta().getPersistentDataContainer().get(jobKey, PersistentDataType.STRING);
        if (id == null || !jobs.containsKey(id)) return;
        getConfig().set("players." + p.getUniqueId() + ".job", id);
        saveConfig();
        p.closeInventory();
        p.sendMessage(ChatColor.GREEN + "Te-ai angajat ca " + ChatColor.GOLD + jobs.get(id).name() + ChatColor.GREEN + "!");
        updateHud(p);
    }

    private void updateHud(Player player) {
        Scoreboard board = hudBoards.computeIfAbsent(player.getUniqueId(), uuid -> {
            oldBoards.put(uuid, player.getScoreboard());
            Scoreboard created = Bukkit.getScoreboardManager().getNewScoreboard();
            Objective objective = created.registerNewObjective("citycraft", "dummy", ChatColor.AQUA + "CITYCRAFT");
            objective.setDisplaySlot(DisplaySlot.SIDEBAR);
            String[] entries = {ChatColor.BLACK.toString(), ChatColor.DARK_BLUE.toString(), ChatColor.DARK_GREEN.toString(), ChatColor.DARK_AQUA.toString(), ChatColor.DARK_RED.toString(), ChatColor.DARK_PURPLE.toString()};
            for (int i = 0; i < entries.length; i++) {
                Team team = created.registerNewTeam("cc_line_" + i);
                team.addEntry(entries[i]);
                objective.getScore(entries[i]).setScore(entries.length - i);
            }
            return created;
        });
        Objective objective = board.getObjective("citycraft");
        String jobId = getConfig().getString("players." + player.getUniqueId() + ".job", "none");
        String jobName = jobs.containsKey(jobId) ? jobs.get(jobId).name() : "Fara job";
        String rank = getRankLabel(player);
        int minutes = Math.max(0, player.getStatistic(Statistic.PLAY_ONE_MINUTE));
        String hours = (minutes / 60) + "h " + (minutes % 60) + "m";
        long cash = countCash(player);
        String[] lines = {
            ChatColor.YELLOW + "ID: " + ChatColor.WHITE + getPlayerId(player),
            ChatColor.YELLOW + "Rank: " + ChatColor.WHITE + rank,
            ChatColor.YELLOW + "Job: " + ChatColor.WHITE + jobName,
            ChatColor.YELLOW + "Ore: " + ChatColor.WHITE + hours,
            ChatColor.GREEN + "Cash: " + ChatColor.WHITE + "$" + cash,
            ChatColor.GRAY + "play.citycraft.ro"
        };
        String[] entries = {ChatColor.BLACK.toString(), ChatColor.DARK_BLUE.toString(), ChatColor.DARK_GREEN.toString(), ChatColor.DARK_AQUA.toString(), ChatColor.DARK_RED.toString(), ChatColor.DARK_PURPLE.toString()};
        for (int i = 0; i < lines.length; i++) {
            Team team = board.getTeam("cc_line_" + i);
            if (team != null) team.setPrefix(lines[i]);
        }
        if (player.getScoreboard() != board) player.setScoreboard(board);
    }

    private String getPlayerId(Player player) {
        String path = "players." + player.getUniqueId() + ".id";
        if (!getConfig().contains(path)) {
            int next = getConfig().getInt("next-id", 1);
            getConfig().set(path, next);
            getConfig().set("next-id", next + 1);
            saveConfig();
        }
        return String.valueOf(getConfig().getInt(path));
    }

    private String getRankLabel(Player player) {
        String display = ChatColor.stripColor(player.getPlayerListName());
        if (display == null || display.isBlank()) display = player.getName();
        String name = player.getName();
        String prefix = display.replace(name, "").trim();
        if (prefix.isBlank()) return player.isOp() ? "Admin" : "Jucator";
        return prefix.length() > 12 ? prefix.substring(0, 12) : prefix;
    }

    private long countCash(Player player) {
        long total = 0;
        for (ItemStack stack : player.getInventory().getStorageContents()) {
            if (stack == null || stack.getAmount() <= 0) continue;
            String id = getForgeItemId(stack);
            Integer value = noteValues.get(id);
            if (value != null) total += (long) value * stack.getAmount();
        }
        ItemStack offhand = player.getInventory().getItemInOffHand();
        if (offhand != null && offhand.getAmount() > 0) {
            Integer value = noteValues.get(getForgeItemId(offhand));
            if (value != null) total += (long) value * offhand.getAmount();
        }
        return total;
    }

    private String getForgeItemId(ItemStack stack) {
        try {
            String craftPackage = Bukkit.getServer().getClass().getPackage().getName();
            Class<?> craftItemStack = Class.forName(craftPackage + ".inventory.CraftItemStack");
            Method asNms = craftItemStack.getMethod("asNMSCopy", ItemStack.class);
            Object nmsStack = asNms.invoke(null, stack);
            Object item = nmsStack.getClass().getMethod("getItem").invoke(nmsStack);
            Class<?> registries = Class.forName("net.minecraft.core.registries.BuiltInRegistries");
            Object itemRegistry = registries.getField("ITEM").get(null);
            Method getKey = null;
            for (Method method : itemRegistry.getClass().getMethods()) {
                if (method.getName().equals("getKey") && method.getParameterCount() == 1) { getKey = method; break; }
            }
            if (getKey == null) return "";
            Object key = getKey.invoke(itemRegistry, item);
            return String.valueOf(key);
        } catch (Exception ignored) {
            return "";
        }
    }

    private void restoreBoard(Player player) {
        Scoreboard old = oldBoards.remove(player.getUniqueId());
        hudBoards.remove(player.getUniqueId());
        if (old != null) player.setScoreboard(old);
    }

    private boolean payCash(Player player, int amount) {
        int[] values = {100, 50, 20, 10, 5, 1};
        String[] ids = {
            "good_ol_currency_reforged:onehundred_dollar",
            "good_ol_currency_reforged:fifty_dollar",
            "good_ol_currency_reforged:twenty_dollar",
            "good_ol_currency_reforged:ten_dollar",
            "good_ol_currency_reforged:five_dollar",
            "good_ol_currency_reforged:one_dollar"
        };
        List<ItemStack> notes = new ArrayList<>();
        int remaining = amount;
        try {
            for (int i = 0; i < values.length; i++) {
                int count = remaining / values[i];
                remaining %= values[i];
                if (count > 0) notes.add(createForgeItem(ids[i], count));
            }
        } catch (Exception ex) {
            getLogger().warning("Nu pot crea bancnotele Good Ol' Currency: " + ex.getMessage());
            return false;
        }
        Map<Integer, ItemStack> leftovers = player.getInventory().addItem(notes.toArray(new ItemStack[0]));
        leftovers.values().forEach(item -> player.getWorld().dropItemNaturally(player.getLocation(), item));
        return true;
    }

    // Uses Forge registry + Arclight's CraftItemStack bridge without a compile-time Forge dependency.
    private ItemStack createForgeItem(String registryId, int count) throws Exception {
        Class<?> resourceLocation = Class.forName("net.minecraft.resources.ResourceLocation");
        Object location;
        try { location = resourceLocation.getMethod("tryParse", String.class).invoke(null, registryId); }
        catch (NoSuchMethodException ignored) { location = resourceLocation.getConstructor(String.class).newInstance(registryId); }
        Class<?> forgeRegistries = Class.forName("net.minecraftforge.registries.ForgeRegistries");
        Object itemRegistry = forgeRegistries.getField("ITEMS").get(null);
        Method getValue = itemRegistry.getClass().getMethod("getValue", resourceLocation);
        Object item = getValue.invoke(itemRegistry, location);
        if (item == null) throw new IllegalStateException("Item inexistent: " + registryId);
        Class<?> itemLike = Class.forName("net.minecraft.world.level.ItemLike");
        Class<?> nmsStack = Class.forName("net.minecraft.world.item.ItemStack");
        Constructor<?> ctor = nmsStack.getConstructor(itemLike, int.class);
        Object nativeStack = ctor.newInstance(item, count);
        String craftPackage = Bukkit.getServer().getClass().getPackage().getName();
        Class<?> craftItemStack = Class.forName(craftPackage + ".inventory.CraftItemStack");
        for (Method method : craftItemStack.getMethods()) {
            if (method.getName().equals("asBukkitCopy") && method.getParameterCount() == 1) {
                return (ItemStack) method.invoke(null, nativeStack);
            }
        }
        throw new NoSuchMethodException("CraftItemStack.asBukkitCopy");
    }
}
